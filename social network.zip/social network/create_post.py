import requests

response = requests.get('http://hashtags.pythonanywhere.com/create_post/')
