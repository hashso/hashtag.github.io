from django.apps import AppConfig


class DialogsConfig(AppConfig):
    name = 'dialogs'
