from django.apps import AppConfig


class BotsConfig(AppConfig):
    name = 'bots'
